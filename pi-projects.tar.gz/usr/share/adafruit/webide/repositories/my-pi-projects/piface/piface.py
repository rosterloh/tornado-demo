import threading
import signal, sys
from time import sleep
import pifacedigitalio

bool = False
#loopend = True

if __name__ == "__main__":
    pifacedigitalio.init()
    pifacedigital = pifacedigitalio.PiFaceDigital()
    
class myThread ( threading.Thread ):
    def __init__( self, Name, LED, TimeOn, TimeOff, Cycles ):
        threading.Thread.__init__( self )
        self.Name = Name
        self.LED = LED
        self.TimeOn = TimeOn
        self.TimeOff = TimeOff
        self.Cycles = Cycles
    def run( self ):
        while self.Cycles > 0:
            if pifacedigital.switches[0].value == 1:
                bool = True
                cycleend = True
                while bool == True:
                    while cycleend == True:
                        print "Starting: " + self.Name
                        LEDFlash( self.Name, self.LED, self.TimeOn, self.TimeOff )
                        self.Cycles -=1
                        if self.Cycles == 0:
                            self.Cycles = -1
                            bool = False
                            cycleend = False
                        if pifacedigital.switches[0].value == 1:
                            cycleend = False
                            print "Ending all current Cycles"
                        print "Exiting: " + self.Name
        while self.Cycles == 0:            
            if pifacedigital.switches[0].value == 1:
                loopbool = True
                loopend = True
                while loopbool == True:
                    while loopend == True:
                        #print "Looping: " + self.Name
                        LEDFlash( self.Name, self.LED, self.TimeOn, self.TimeOff )
                        if pifacedigital.switches[0].value == 1:
                            loopend = False

# Define a function for the thread
def LEDFlash( threadName, LEDNumber, DelayOn, DelayOff ):
        pifacedigital.leds[LEDNumber].turn_on()
        sleep( DelayOn )
        pifacedigital.leds[LEDNumber].turn_off()
        sleep( DelayOff )
    
# Create threads as follows
ThreadOne = myThread ( "Thread One", 7, .1, .1, 0 )
ThreadTwo = myThread ( "Thread Two", 6, .1, .1, 0 )
ThreadThree = myThread ( "Thread Three", 5, .1, .1, 0 )
ThreadFour = myThread ( "Thread Four", 4, .1, .1, 0 )
ThreadFive = myThread ( "Thread Five", 3, .1, .1, 0 )
ThreadSix = myThread ( "Thread Six", 2, .1, .1, 0 )
ThreadSeven = myThread ( "Thread Seven", 1, .1, .1, 10 )
ThreadEight = myThread ( "Thread Eight", 0, .1, .1, 10 )


#try:
ThreadOne.start()
ThreadTwo.start()
ThreadThree.start()
ThreadFour.start()
ThreadFive.start()
ThreadSix.start()
ThreadSeven.start()
ThreadEight.start()
    
#except:
#   print "Error: unable to start thread"

def handle(a, b):
    #ThreadOne.exit()
    #ThreadTwo.exit()
    print "Finished"
    pifacedigital.output_port.value = 0
    sys.exit()

signal.signal( signal.SIGINT, handle )

while True:
    pass