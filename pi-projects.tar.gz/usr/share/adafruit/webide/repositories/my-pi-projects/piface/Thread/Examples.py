from time import sleep
import pifacedigitalio


DELAY = .5  # seconds
DELAYTWO = .5
NUMBER = 0

if __name__ == "__main__":
    pifacedigitalio.init()
    pifacedigital = pifacedigitalio.PiFaceDigital()
    while True:
        pifacedigital.leds[NUMBER].turn_on()
        print( "LED Number: " )
        print( NUMBER + 1 )
        sleep(DELAY)
        pifacedigital.leds[NUMBER].turn_off()
        NUMBER+=1
        if NUMBER > 7:
            NUMBER = 0
            