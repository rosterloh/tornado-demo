import threading
import time
import pifacedigitalio

exitFlag = 0
bool = False

if __name__ == "__main__":
    pifacedigitalio.init()
    pifacedigital = pifacedigitalio.PiFaceDigital()

class myThread (threading.Thread):
    def __init__(self, Name, LEDN, TimeOn, TimeOff):
        threading.Thread.__init__(self)
        self.Name = Name
        self.LEDN = LEDN
        self.TimeOn = TimeOn
        self.TimeOff = TimeOff
        #self.Cycles = Cycles
    def run(self):
        print "Starting " + self.Name
        LEDFunction(self.Name, self.LEDN, self.TimeOn, self.TimeOff)
        print "Exiting " + self.Name

def LEDFunction( Name, LEDN, TimeOn, TimeOff ):
    pifacedigital.leds[LEDN].Turn_On()
    sleep(TimeOn)
    pifacedital.leds[LEDN].Turn_off()
    sleep(TimeOff)

# Create new threads
thread1 = myThread( "Thread One", 0, 1, 1)
thread2 = myThread( "Thread Two", 1, 1, 1)

# Start new Threads
if pifacedigital.switches[0].value == 1:
    bool = True
    while bool == True:
        thread1.start()
        thread2.start()

print "Exiting Main Thread"