from flask import Flask, render_template, request, jsonify
app = Flask(__name__)

import threading
import signal, sys
import pifacedigitalio
from time import sleep

if __name__ == "__main__":
    pifacedigitalio.init()
    pifacedigital = pifacedigitalio.PiFaceDigital()

class MyLED ( threading.Thread ):
    def __init__( self, Name, LED, TimeOn, TimeOff, Cycles ):
        threading.Thread.__init__( self )
        self.Name = Name
        self.LED = LED
        self.TimeOn = TimeOn
        self.TimeOff = TimeOff
        self.Cycles = Cycles
        self.Active = False
    def run( self ):
        #print "Starting LED Cycle", self.name
        while True:
            while self.Active:
                infinite = False
                if self.Cycles == 0:
                    self.Cycles = 1
                    infinite = True
                while (self.Cycles > 0 or infinite) and self.Active:
                    pifacedigital.leds[self.LED].turn_on()
                    sleep( self.TimeOn )
                    pifacedigital.leds[self.LED].turn_off()
                    sleep( self.TimeOff )
                    self.Cycles -=1
                    if self.Cycles == 0:
                        self.Active = False
        
outputs = [
    { 
      'name': 'output0',
      'value' : 0,
      'index' : 0,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output1',
      'value' : 0,
      'index' : 1,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output2',
      'value' : 0,
      'index' : 2,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output3',
      'value' : 0,
      'index' : 3,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output4',
      'value' : 0,
      'index' : 4,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output5',
      'value' : 0,
      'index' : 5,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output6',
      'value' : 0,
      'index' : 6,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    },
    {
      'name': 'output7',
      'value' : 0,
      'index' : 7,
      'count' : 1,
      'Ton'   : 1,
      'Toff'  : 1,
      'Active': False
    }
  ]

#Creates Thread Loops
LED=[]
for x in range(0, 8):
    LED.append(MyLED( x, outputs[x]['index'], outputs[x]['Ton'], outputs[x]['Toff'], outputs[x]['count'] ))
    LED[x].start()
    
@app.route('/run_output/', methods=['GET'])
def run_output():
    count = request.args.get('count', type=int)
    index = request.args.get('index', type=int)
    value = request.args.get('value', type=int)
    ton = request.args.get('ton', type=int)
    toff = request.args.get('toff', type=int)
    print "Output" + str(index) + " is " + str(value) + ". On For: ", ton, "Second(s). Off for: ", toff, "second(s). Start " + str(count) + " times.", "Active is: ", LED[index].Active
    print "DEBUG: ", LED[index].Active, LED[index].Cycles, LED[index].TimeOn, LED[index].TimeOff
    LED[index].Active = not LED[index].Active
    LED[index].Cycles = count
    LED[index].TimeOn = ton
    LED[index].TimeOff = toff
    print "DEBUG: ", LED[index].Active, LED[index].Cycles, LED[index].TimeOn, LED[index].TimeOff
    return jsonify(result=1)


@app.route('/')
@app.route('/index')
def index():
    header = { 'message': 'PiFace Output Values' }

    return render_template("index.html",
        title = 'PiFace Control',
        header = header,
        outputs = outputs)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000,  debug=True)
    
    
def handle(a, b):
    #ThreadOne.exit()
    #ThreadTwo.exit()
    print "Finished"
    pifacedigital.output_port.value = 0
    sys.exit()
signal.signal( signal.SIGINT, handle )

while True:
    pass
