from flask import Flask, render_template, request, jsonify
app = Flask(__name__)

@app.route('/run_output/', methods=['GET'])
def run_output():
  count = request.args.get('count', type=int)
  index = request.args.get('index', type=int)
  value = request.args.get('value', type=int)
  print "Output" + str(index) + " is " + str(value) + ". Start " + str(count) + " times."
  return jsonify(result=1)

@app.route('/')
@app.route('/index')
def index():
  header = { 'message': 'PiFace Output Values' }
  outputs = [
    { 
      'name': 'LED 1',
      'value' : 0,
      'index' : 0,
      'count' : 0 
    },
    {
      'name': 'LED 2',
      'value' : 0,
      'index' : 1,
      'count' : 0
    },
    {
      'name': 'LED 3',
      'value' : 0,
      'index' : 2,
      'count' : 0
    },
    {
      'name': 'LED 4',
      'value' : 0,
      'index' : 3,
      'count' : 0
    },
    {
      'name': 'LED 5',
      'value' : 0,
      'index' : 4,
      'count' : 0
    },
    {
      'name': 'LED 6',
      'value' : 0,
      'index' : 5,
      'count' : 0
    },
    {
      'name': 'LED 7',
      'value' : 0,
      'index' : 6,
      'count' : 0
    },
    {
      'name': 'LED 8',
      'value' : 0,
      'index' : 7,
      'count' : 0
    }
  ]
  return render_template("index.html",
        title = 'PiFace Control',
        header = header,
        outputs = outputs)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000,  debug=True)
